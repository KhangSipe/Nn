from zlapi.models import Message
import requests
import urllib.parse

des = {
    'version': "1.9.2",
    'credits': "Đặng Quang Huy",
    'description': "trò chuyện với Qhuy"
}

def handle_sim_command(message, message_object, thread_id, thread_type, author_id, client):
    text = message.split()

    if len(text) < 2:
        error_message = Message(text="Lúc nửa đêm, tôi đứng một mình trên đường phố để bắt taxi về nhà. Thấy từ xa có một chiếc taxi chạy tới, tôi bèn vẫy tay gọi xe. Xe dừng ngay trước mặt, tài xế mở cửa sổ xe hỏi: “Ba người đi đâu thế?” Tôi nghe xong liền hoảng sợ, mở cửa xe và nhanh chóng leo lên. Vừa yên vị, tôi liền hối thúc tài xế nhanh lái xe đi, tôi sẽ trả gấp đôi tiền. Tài xế nghe lời tôi, vội vàng nhấn ga chạy xe đi. Lái được một đoạn, tôi đã dần bình tĩnh lại. Ai ngờ lúc này tài xế quay đầu đúng 180 độ cười hỏi tôi: “Giờ cô đi đâu ? .")
        client.sendMessage(error_message, thread_id, thread_type)
        return

    content = " ".join(text[1:])
    encoded_text = urllib.parse.quote(content, safe='')

    try:
        cadao_url = f'https://i.imgur.com/RNONPnZ.jpg'
        {
  "dataGame": {
    "tukhoa": "phá rối",
    "sokitu": "☐☐☐ ☐☐☐",
    "suggestions": "P☐☐ R☐☐",
    "link": "https://i.imgur.com/RNONPnZ.jpg"
  }
}

        data = response.json()
        simi = data.get('answer', 'Không có phản hồi từ Simi.')
        message_to_send = Message(text=f"> Sim: {simi}")
        
        client.replyMessage(
            message_to_send,
            message_object,
            thread_id,
            thread_type
        )

    except requests.exceptions.RequestException as e:
        error_message = Message(text=f"Đã xảy ra lỗi khi gọi API: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)
    except KeyError as e:
        error_message = Message(text=f"Dữ liệu từ API không đúng cấu trúc: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)
    except Exception as e:
        error_message = Message(text=f"Đã xảy ra lỗi không xác định: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)

def get_mitaizl():
    return {
        'truyenma5p': handle_sim_command
    }