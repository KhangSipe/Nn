import os
from zlapi.models import Message
import importlib

# Thông tin về lệnh 'help'
des = {
    'version': "1.0.0",
    'credits': "MrQ",
    'description': "𝕃𝕖̣̂𝕟𝕙 𝕟𝕒̀𝕪 𝕔𝕦𝕟𝕘 𝕔𝕒̂́𝕡 𝕥𝕙𝕠̂𝕟𝕘 𝕥𝕚𝕟 𝕔𝕙𝕚 𝕥𝕚𝕖̂́𝕥 𝕧𝕖̂̀ 𝕔𝕒́𝕔 𝕝𝕖̣̂𝕟𝕙 𝕜𝕙𝕒́𝕔."
}

# Hàm lấy thông tin về tất cả các lệnh trong thư mục 'module'
def get_all_MrQ_with_info():
    MrQ_info = {}

    # Duyệt qua tất cả các module trong thư mục 'module'
    for module_name in os.listdir('module'):
        if module_name.endswith('.py') and module_name != '__init__.py':
            module_path = f'module.{module_name[:-3]}'
            try:
                # Tải module và kiểm tra thông tin lệnh
                module = importlib.import_module(module_path)
                if hasattr(module, 'des'):
                    des = getattr(module, 'des')
                    version = des.get('version', 'Chưa có thông tin')
                    credits = des.get('credits', 'Chưa có thông tin')
                    description = des.get('description', 'Chưa có thông tin')
                    MrQ_info[module_name[:-3]] = (version, credits, description)
            except ImportError:
                print(f"Không thể tải module {module_name}.")
    
    return MrQ_info

# Hàm xử lý lệnh 'help'
def handle_help_command(message, message_object, thread_id, thread_type, author_id, client):
    command_parts = message.split()
    
    # Lấy thông tin về các lệnh
    MrQ_info = get_all_MrQ_with_info()

    # Kiểm tra xem người dùng có yêu cầu chi tiết cho một lệnh cụ thể hay không
    if len(command_parts) > 1:
        requested_command = command_parts[1].lower()

        if requested_command in MrQ_info:
            version, credits, description = MrQ_info[requested_command]
            # Hiển thị đầy đủ thông tin về lệnh
            single_command_help = (
                f"• 𝕋𝕖̂𝕟 𝕝𝕖̣̂𝕟𝕙: {requested_command}\n"
                f"• ℙ𝕙𝕚𝕖̂𝕟 𝕓𝕒̉𝕟: {version}\n"
                f"• ℂ𝕣𝕖𝕕𝕚𝕥𝕤: {credits}\n"
                f"• 𝕄𝕠̂ 𝕥𝕒̉: {description}"
            )
            all_commands_help = None
        else:
            single_command_help = f"Không tìm thấy lệnh '{requested_command}' trong hệ thống."
            all_commands_help = None
    else:
        # Nếu không có lệnh cụ thể, hiển thị mô tả của tất cả các lệnh
        total_MrQ = len(MrQ_info)
        help_message_lines = [f"𝕋𝕠̂̉𝕟𝕘 𝕤𝕠̂́ 𝕝𝕖̣̂𝕟𝕙 𝕓𝕠𝕥 𝕙𝕚𝕖̣̂𝕟 𝕥𝕒̣𝕚: {total_MrQ} 𝕝𝕖̣̂𝕟𝕙"]

        # Chỉ liệt kê tên lệnh và mô tả của từng lệnh
        for i, (name, (_, _, description)) in enumerate(MrQ_info.items(), 1):
            help_message_lines.append(f"{i}:\n• Tên Lệnh: {name}\n• Mô tả: {description}\n")
        
        all_commands_help = "\n".join(help_message_lines)
        single_command_help = None

    # Gửi thông báo về lệnh cụ thể hoặc tất cả lệnh tùy vào yêu cầu của người dùng
    if single_command_help:
        message_to_send = Message(text=single_command_help)
    else:
        message_to_send = Message(text=all_commands_help)

    client.replyMessage(message_to_send, message_object, thread_id, thread_type,ttl=60000)

# Hàm lấy các lệnh bot
def get_mitaizl():
    return {
        'help': handle_help_command
    }
