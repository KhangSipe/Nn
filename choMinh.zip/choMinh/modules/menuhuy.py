import os
import importlib
import math
from zlapi.models import Message, MultiMsgStyle, MessageStyle

# Copyright Tamhoangdz
def get_all_mitaizl():
    mitaizl = {}

    # Lặp qua các module trong thư mục 'modules'
    for module_name in os.listdir('modules'):
        if module_name.endswith('.py') and module_name != '__init__.py':
            module_path = f'modules.{module_name[:-3]}'
            module = importlib.import_module(module_path)

            if hasattr(module, 'get_mitaizl'):
                module_mitaizl = module.get_mitaizl()
                mitaizl.update(module_mitaizl)

    command_names = list(mitaizl.keys())
    return command_names

# Copyright DzixTool
def handle_menu_command(message, message_object, thread_id, thread_type, author_id, client):
    # Lấy tất cả các lệnh
    command_names = get_all_mitaizl()
    total_commands = len(command_names)
    
    # Xác định số trang tổng
    total_pages = math.ceil(total_commands / 5)  # Giả sử mỗi trang hiển thị 10 lệnh
    
    # Lấy số trang từ lệnh của người dùng (mặc định là trang 1)
    page_number = 1
    if message.startswith("menu"):
        try:
            page_number = int(message.split()[1])
        except (IndexError, ValueError):
            page_number = 1

    # Đảm bảo số trang hợp lệ
    page_number = max(1, min(total_pages, page_number))

    # Tính toán phạm vi các lệnh hiển thị trên trang
    items_per_page = 5  # Số lượng lệnh hiển thị trên mỗi trang
    start_index = (page_number - 1) * items_per_page
    end_index = min(start_index + items_per_page, total_commands)
    paged_commands = command_names[start_index:end_index]

    # Tạo danh sách các lệnh số thứ tự
    numbered_mitaizl = [f"{i + 1 + start_index}. {name}" for i, name in enumerate(paged_commands)]
    
    # Tạo thông báo menu
    menu_message = (
        f"==== [ 𝕄𝕖𝕟𝕦 ℂ𝕦̉𝕒 𝔹𝕠𝕥 ] ====\n🌟 ℂ𝕙𝕦̉ ℕ𝕙𝕒̂𝕟 : 𝔻𝕦𝕪\n👑 𝔸𝕕𝕞𝕚𝕟 : 𝔻𝕦𝕪 𝕄𝕠𝕕𝕤\n"
        f"📋 𝕋𝕠̂̉𝕟𝕘 𝕤𝕠̂́ 𝕝𝕖̣̂𝕟𝕙 : {total_commands}\n"
        "" + "\n".join(numbered_mitaizl) + "\n"
        f"𝕋𝕣𝕒𝕟𝕘 {page_number}/{total_pages}"
        f" :𝔻𝕦𝕟𝕘 𝕝𝕖̣̂𝕟𝕙 𝕞𝕖𝕟𝕦 <𝕤𝕠̂́_𝕥𝕣𝕒𝕟𝕘> 𝕕𝕖̂̉ 𝕔𝕙𝕦𝕪𝕖̂̉𝕟 𝕥𝕣𝕒𝕟𝕘."
    )

    # Tính độ dài của tin nhắn để áp dụng style
    msg_length = len(menu_message)
    style = MultiMsgStyle([
        MessageStyle(offset=0, length=msg_length, style="color", color="40ff00", auto_format=False),
        MessageStyle(offset=0, length=msg_length, style="font", size="0", auto_format=False),
        MessageStyle(offset=0, length=msg_length, style="sansserif", auto_format=False)
    ])

    # Tạo và gửi tin nhắn
    message_to_send = Message(text=menu_message, style=style)
    client.replyMessage(message_to_send, message_object, thread_id, thread_type)

def get_mitaizl():
    return {
        'menuminh': handle_menu_command
    }