from zlapi.models import Message
import random
import os
import requests


def handle_girl_command(message, message_object, thread_id, thread_type, author_id, client):
    """Gửi ảnh trai ngẫu nhiên từ file girl.txt.
    - quyền hạn: all
    """
    handle_girl_command.permission = "all"

    try:
        # Đọc tất cả các URL từ file girl.txt
        with open('nb.txt', 'r') as file:
            urls = file.readlines()
        
        # Kiểm tra xem có URL nào không
        if not urls:
            error_message = Message(text="Không có URL nào trong tệp girl.txt.")
            client.sendMessage(error_message, thread_id, thread_type)
            return

        # Chọn ngẫu nhiên một URL và lấy số thứ tự
        selected_url = random.choice(urls).strip()  # Loại bỏ khoảng trắng
        index = urls.index(f"{selected_url}\n") + 1  # Lấy số thứ tự (1-based)

        # Tạo tin nhắn
        message_to_send = Message(text=f"NO: {index}")

        # Tải ảnh và gửi
        image_response = requests.get(selected_url)
        image_path = 'temp_image.jpg'
        with open(image_path, 'wb') as f:
            f.write(image_response.content)

        client.sendLocalImage(
            image_path,
            message=message_to_send,
            thread_id=thread_id,
            thread_type=thread_type,
            width=1200,
            height=1600
        )

        os.remove(image_path)

    except FileNotFoundError:
        error_message = Message(text="Tệp girl.txt không tồn tại.")
        client.sendMessage(error_message, thread_id, thread_type)
    except requests.exceptions.RequestException as e:
        error_message = Message(text=f"Đã xảy ra lỗi khi tải ảnh: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)
    except Exception as e:
        error_message = Message(text=f"Đã xảy ra lỗi: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)

def get_mitaizl():
    return {
        'sexnb': handle_girl_command
    }