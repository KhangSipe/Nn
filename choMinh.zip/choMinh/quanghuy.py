from config import API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES, PREFIX
from mitaizl import CommandHandler
from zlapi import ZaloAPI
from zlapi.models import Message
from modules.bot_info import *
from colorama import Fore, Style, init
from modules.welcome import welcome
import logging

# Initialize logger
logger = logging.getLogger("ZaloBot")
logging.basicConfig(level=logging.ERROR)

init(autoreset=True)

class Client(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies):
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)
        self.admin = "841104038324796716"
        self.version = 1.0
        self.me_name = "Bot by tamhoangdz"
        self.date_update = "29/9/2024"
        self.command_handler = CommandHandler(self)
        self.is_mute_list = {}  # Tạo danh sách mute theo thread ID

    def onEvent(self, event_data, event_type):
        welcome(self, event_data, event_type)

    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        print(f"{Fore.GREEN}{Style.BRIGHT}------------------------------\n"
              f"**Message Details:**\n"
              f"- **Message:** {Style.BRIGHT}{message} {Style.NORMAL}\n"
              f"- **Author ID:** {Fore.MAGENTA}{Style.BRIGHT}{author_id} {Style.NORMAL}\n"
              f"- **Thread ID:** {Fore.YELLOW}{Style.BRIGHT}{thread_id}{Style.NORMAL}\n"
              f"- **Thread Type:** {Fore.BLUE}{Style.BRIGHT}{thread_type}{Style.NORMAL}\n"
              f"- **Message Object:** {Fore.RED}{Style.BRIGHT}{message_object}{Style.NORMAL}\n"
              f"{Fore.GREEN}{Style.BRIGHT}------------------------------\n"
              )
        allowed_thread_ids = get_allowed_thread_ids()
        if thread_id in allowed_thread_ids and thread_type == ThreadType.GROUP and not is_admin(author_id):
            handle_check_profanity(self, author_id, thread_id, message_object, thread_type, message)
        try:
            if isinstance(message, str):
                # Kiểm tra nếu thread đang bị mute và người gửi trong danh sách mute
                if self.is_mute_list.get(thread_id) and author_id in self.is_mute_list[thread_id]:
                    self.deleteGroupMsg(message_object.msgId, message_object.uidFrom, message_object.cliMsgId, thread_id)
                    return  # Không xử lý tiếp nếu đã xóa tin nhắn
                
                if message == f"{PREFIX}":
                    self.send(Message(text=f"Dùng {PREFIX}menu để biết rõ hơn"), thread_id, thread_type)
                    return
                
                self.command_handler.handle_command(message, author_id, message_object, thread_id, thread_type)
        except Exception as e:
            logger.error(f"Lỗi xử lý tin nhắn: {e}")

if __name__ == "__main__":
    client = Client(API_KEY, SECRET_KEY, IMEI, SESSION_COOKIES)
    client.listen()