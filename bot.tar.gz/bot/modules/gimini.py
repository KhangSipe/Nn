from zlapi.models import Message
import requests
from zlapi import *
from zlapi.models import *
from zlapi.models import Message

def handle_gemini_command(ask):
        try:
            response = requests.post(
                'https://generativelanguage.googleapis.com/v1beta/models/gemini-1.5-pro:generateContent',
                params={'key': 'AIzaSyDYwf7Zofp0hMVhKozXI6UetOxpjeRa8FI'},
                headers={'Content-Type': 'application/json'},
                json={'contents': [{'parts': [{'text': ask}]}]}
            ).json()
            
            if 'candidates' in response and len(response['candidates']) > 0:
                an = response['candidates'][0]['content']['parts'][0]['text']
                return an
            else:
                print("Không có phản hồi từ API.")
                return False
        except Exception as e:
            print(e)
            return False
        
def get_mitaizl():
    return {
        'gemini': handle_gemini_command
    }