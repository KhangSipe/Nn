from zlapi.models import Message
import requests
import urllib.parse

des = {
    'version': "1.9.2",
    'credits': "Đặng Quang Huy",
    'description': "trò chuyện với Qhuy"
}

def handle_sim_command(message, message_object, thread_id, thread_type, author_id, client):
    text = message.split()

    if len(text) < 2:
        error_message = Message(text="📑Một số lệnh đang có của bot :\n🔸Menuv1 : Xem Tất Cả Lệnh\n🔸War :Spam Bình Thường + rain\n🔸Reo :Réo Tên + Rain\n🔸Vd-Video :Các Thể Loại Video\n🔸Anh - anh :Xem Các Thể Loại Ảnh\n🔸Dl :Tải ảnh video từ các nền tảng\n🔸Uptime :Xem Thời Gian Của Bot\n🔸Ping :Xem ảnh và tốc độ\n🔸Sim :Nói Chuyện Cùng Hệ Thống Ai")
        client.sendMessage(error_message, thread_id, thread_type)
        return

    content = " ".join(text[1:])
    encoded_text = urllib.parse.quote(content, safe='')

    try:
        sim_url = f'https://subhatde.id.vn/sim?type=ask&ask={encoded_text}'
        response = requests.get(sim_url)
        response.raise_for_status()

        data = response.json()
        simi = data.get('answer', 'Không có phản hồi từ Simi.')
        message_to_send = Message(text=f"> Sim: {simi}")
        
        client.replyMessage(
            message_to_send,
            message_object,
            thread_id,
            thread_type
        )

    except requests.exceptions.RequestException as e:
        error_message = Message(text=f"Đã xảy ra lỗi khi gọi API: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)
    except KeyError as e:
        error_message = Message(text=f"Dữ liệu từ API không đúng cấu trúc: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)
    except Exception as e:
        error_message = Message(text=f"Đã xảy ra lỗi không xác định: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)

def get_mitaizl():
    return {
        'helpv2': handle_sim_command
    }