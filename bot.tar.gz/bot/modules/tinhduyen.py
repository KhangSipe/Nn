from zlapi import ZaloAPI, ZaloAPIException
from zlapi.models import *
import requests
import json
import os

# Hàm bói tình duyên
def boi_tinh_duyen(ten_nam, ten_nu):
    ten_nam = ten_nam.lower()
    ten_nu = ten_nu.lower()
    den = 0
    for chu_cai in range(ord("a"), ord("z") + 1):
        if (chr(chu_cai) in ten_nam) and (chr(chu_cai) in ten_nu):
            den += 1

    if den == 0:
        ket_qua = "người dân nước đái"
    elif den < 1:
        ket_qua = "đã từng chịch nhau"
    else:
        ket_qua = "sinh ra là để cho nhau"
    return ket_qua

# Hàm xử lý lệnh bói tình duyên
def handle_boi_tinh_duyen_command(message, message_object, thread_id, thread_type, author_id, client):
    if len(message_object.mentions) != 2:
        client.replyMessage(Message(text="vui lòng tag tên 2 người vào"), message_object, thread_id, thread_type, ttl=5000)
    else:
        uid1 = message_object.mentions[0].uid
        uid2 = message_object.mentions[1].uid
        name1 = client.fetchUserInfo(uid1).changed_profiles[uid1].displayName
        name2 = client.fetchUserInfo(uid2).changed_profiles[uid2].displayName
        tt = boi_tinh_duyen(name1, name2)
        client.replyMessage(Message(text=tt), message_object, thread_id, thread_type)

# Class kế thừa ZaloAPI
class Client(ZaloAPI):
    def __init__(self, api_key, secret_key, imei, session_cookies):
        super().__init__(api_key, secret_key, imei=imei, session_cookies=session_cookies)
    
    def onMessage(self, mid, author_id, message, message_object, thread_id, thread_type):
        if not isinstance(message, str):
            return
        if author_id == self.uid:  # Không phản hồi tin nhắn của chính mình
            return
        
        if message.startswith("boi"):
            handle_boi_tinh_duyen_command(message, message_object, thread_id, thread_type, author_id, self)

# Hàm trả về các lệnh
def get_mitaizl():
    return {
        'tinhduyen': handle_boi_tinh_duyen_command  # Đúng tên hàm đã định nghĩa
    }