from zlapi.models import Message
import random
import requests

des = {
    'version': "1.0.2",
    'credits': "Dzi x Tool",
    'description': "Gửi video cosplay"
}

def handle_vdgirl_command(message, message_object, thread_id, thread_type, author_id, client):
    # Đường dẫn đến tệp chứa các URL video
    video_file_path = 'vdgirl.txt'
    
    try:
        # Đọc tất cả các URL từ tệp vdgirl.txt
        with open(video_file_path, 'r') as file:
            urls = file.readlines()
        
        # Kiểm tra xem có URL nào không
        if not urls:
            error_message = Message(text="Không có URL nào trong tệp vdgirl.txt.")
            client.sendMessage(error_message, thread_id, thread_type)
            return

        # Chọn ngẫu nhiên một URL và xác định chỉ số của nó
        selected_index = random.randint(0, len(urls) - 1)
        selected_url = urls[selected_index].strip()  # Loại bỏ khoảng trắng
        thumbnail_url = selected_url  # Sử dụng URL video làm thumbnail
        duration = '1000'  # Thời gian mặc định, có thể thay đổi nếu cần

        # Tạo tin nhắn với số thứ tự
        message_text = f"NO: {selected_index + 1}"
        message_to_send = Message(text=message_text)

        # Gửi video
        client.sendRemoteVideo(
            selected_url, 
            thumbnail_url,
            duration=duration,
            message=message_to_send,
            thread_id=thread_id,
            thread_type=thread_type,
            width=1080,
            height=1920
        )
        
    except FileNotFoundError:
        error_message = Message(text="Tệp vdgirl.txt không tồn tại.")
        client.sendMessage(error_message, thread_id, thread_type)
    except requests.exceptions.RequestException as e:
        error_message = Message(text=f"Đã xảy ra lỗi khi gọi API: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)
    except Exception as e:
        error_message = Message(text=f"Đã xảy ra lỗi: {str(e)}")
        client.sendMessage(error_message, thread_id, thread_type)

def get_mitaizl():
    return {
        'vdgirl': handle_vdgirl_command
    }