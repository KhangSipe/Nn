from zlapi.models import Message, Mention, MultiMention

def handle_meid_command(message, message_object, thread_id, thread_type, author_id, client):
    user_id = author_id

    response_message = f"{user_id}"

    message_to_send = Message(text=response_message)

    client.replyMessage(message_to_send, message_object, thread_id, thread_type,ttl=600000)
def get_mitaizl():
    return {
        "uid": handle_meid_command
    }