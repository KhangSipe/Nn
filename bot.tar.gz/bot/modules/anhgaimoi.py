from zlapi.models import Message
import requests
import random
import os
import threading
import time

des = {
    'version': "1.0.1",
    'credits': "𝕄𝕣ℚ",
    'description': "𝔾𝕦̛̉𝕚 𝕒̉𝕟𝕙 𝕘𝕒́𝕚 𝕧𝕒̀ 𝕔𝕒̂𝕦 𝕥𝕙𝕚́𝕟𝕙"
}

OWNER_NAME = "𝕄𝕣ℚ"  # Thay đổi tên chủ nhân ở đây

def fetch_data(url):
    """Lấy dữ liệu từ URL và kiểm tra lỗi."""
    response = requests.get(url)
    response.raise_for_status()
    return response.json()

def fetch_thinh():
    """Lấy câu thính từ API."""
    return fetch_data("https://api.ntmdz.online/poem/love").get('data', 'Không có câu thính')

def fetch_image_url():
    """Lấy URL của hình ảnh ngẫu nhiên từ danh sách."""
    json_data = fetch_data("https://raw.githubusercontent.com/quang07/list/refs/heads/main/listimg.json")
    return json_data.get('data') if isinstance(json_data, dict) else random.choice(json_data)

def download_image(image_url, image_path, retries=3):
    """Tải xuống hình ảnh và lưu vào tệp với số lần thử lại."""
    for attempt in range(retries):
        try:
            response = requests.get(image_url, headers={'User-Agent': 'Mozilla/5.0'}, timeout=10)  # Thêm thời gian chờ
            response.raise_for_status()
            with open(image_path, 'wb') as f:
                f.write(response.content)
            return  # Nếu thành công, thoát khỏi vòng lặp
        except requests.exceptions.RequestException as e:
            if attempt < retries - 1:
                time.sleep(2)  # Đợi 2 giây trước khi thử lại
                continue  # Thử lại
            else:
                raise e  # Ném ngoại lệ nếu đã thử hết số lần

def send_image(thinh, image_url, thread_id, thread_type, client):
    """Gửi hình ảnh và câu thính."""
    image_path = 'modules/cache/temp_image.jpeg'  # Sử dụng cùng một đường dẫn cho mỗi hình ảnh
    try:
        download_image(image_url, image_path)
        client.sendLocalImage(
            image_path,
            message=Message(text=thinh),
            thread_id=thread_id,
            thread_type=thread_type, ttl=6000000000000,
            width=1200,
            height=1600
        )
    except Exception as e:
        client.sendMessage(Message(text=f"❌ Lỗi khi gửi hình ảnh: {str(e)}"), thread_id, thread_type, ttl=60000)
    finally:
        if os.path.exists(image_path):
            os.remove(image_path)  # Xóa hình ảnh tạm nếu tồn tại

def handle_gai_command(message, message_object, thread_id, thread_type, author_id, client):
    try:
        # Kiểm tra kiểu dữ liệu và lấy nội dung tin nhắn
        message_text = message if isinstance(message, str) else message.text
        
        # Phân tích số lượng hình ảnh được yêu cầu (mặc định là 1)
        parts = message_text.split()
        count = int(parts[1]) if len(parts) > 1 and parts[1].isdigit() else 1
        
        # Kiểm tra số lượng hình ảnh yêu cầu
        if count < 1:
            client.sendMessage(Message(text="❌ Số lượng hình ảnh phải lớn hơn 0."), thread_id, thread_type, ttl=60000)
            return
        elif count > 20:
            client.sendMessage(Message(text="❌ Vượt quá số lượng tối đa là 20 hình ảnh."), thread_id, thread_type, ttl=600000000)
            return

        threads = []
        for _ in range(count):
            thinh = fetch_thinh()
            image_url = fetch_image_url()
            # Tạo một luồng mới để gửi hình ảnh và câu thính
            thread = threading.Thread(target=send_image, args=(thinh, image_url, thread_id, thread_type, client))
            threads.append(thread)
            thread.start()  # Bắt đầu luồng

        for thread in threads:
            thread.join()  # Chờ tất cả các luồng hoàn thành

    except requests.exceptions.RequestException as e:
        client.sendMessage(Message(text=f"❌ Lỗi API: {str(e)}"), thread_id, thread_type, ttl=60000)
    except Exception as e:
        client.sendMessage(Message(text=f"❌ Lỗi: {str(e)}"), thread_id, thread_type, ttl=60000)

def get_mitaizl():
    return {'gai': handle_gai_command}